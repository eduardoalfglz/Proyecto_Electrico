﻿using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Windows.Forms;


namespace ScreenRecorderNET
{
    class ScreenRecorder
    {
        private Rectangle bounds;
        
        //Carpeta de salida
        private string tempFolder = "ScreenRecorderVideoFile";
        private string tempPath = $"C://Documents//ScreenRecorderVideoFile";
        private int fileCount = 1;
        private List<string> inputImageSequence = new List<string>();

        //File variables:
        
            //Nombre del video
        private string videoName = "video.mp4";
        private int framerate = 10;
        //private string finalName = "FinalVideo.mp4";

        //Time variable:
        Stopwatch watch = new Stopwatch();

      

        //ScreenRecorder Object:
        public ScreenRecorder(int Framerate, string VideoName)
        {
            //Create temporary folder for screenshots:
            SelectFolder();
            
            Directory.CreateDirectory(tempPath);
            //tempPath = outPath;
            framerate = Framerate;
            videoName = VideoName;
            //Set variables:
            bounds = Screen.PrimaryScreen.Bounds;

        }

       
        public void SelectFolder()
        {
            FolderBrowserDialog folderBrowser = new FolderBrowserDialog();
            folderBrowser.Description = "Select an Output Folder";

            if (folderBrowser.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                string sFolder = @folderBrowser.SelectedPath;
                tempPath = $"{sFolder}//{tempPath}";
                //pathSelected = true;

                //Finish screen recorder object:
                //Rectangle bounds = Screen.FromControl(this).Bounds;
            }
            else
            {
                MessageBox.Show("Please select an output folder.", "Error");
            }
        }

    

        //Delete all files except the one specified:
        private void DeleteFilesExcept(string targetDir, string excDir)
        {
            string[] files = Directory.GetFiles(targetDir);

            //Delete each file except specified:
            foreach (string file in files)
            {
                if (file != excDir)
                {
                    File.SetAttributes(file, FileAttributes.Normal);
                    File.Delete(file);
                }
            }
        }

        //Clean up program on crash:
     

    

        //Record video:
        public void RecordVideo()
        {
            //Keep track of time:
            watch.Start();

            using (Bitmap bitmap = new Bitmap(bounds.Width, bounds.Height))
            {
                using (Graphics g = Graphics.FromImage(bitmap))
                {
                    //Add screen to bitmap:
                    g.CopyFromScreen(new Point(bounds.Left, bounds.Top), Point.Empty, bounds.Size);
                }
                //Save screenshot:
                string name = tempPath + "//screenshot-" + fileCount + ".png";
                bitmap.Save(name, ImageFormat.Png);
                inputImageSequence.Add(name);
                fileCount++;

                //Dispose of bitmap:
                bitmap.Dispose();
            }
        }

     

       
        private void SaveVideo()
        {
            string strCmdText;


            Process cmd = new Process();
            cmd.StartInfo.FileName = "cmd.exe";
            cmd.StartInfo.RedirectStandardInput = true;
            //cmd.StartInfo.RedirectStandardOutput = true;
            cmd.StartInfo.CreateNoWindow = true;
            cmd.StartInfo.WorkingDirectory = tempPath;
            cmd.StartInfo.UseShellExecute = false;
            cmd.Start();


            strCmdText = $"ffmpeg -r {framerate} -f image2 -i screenshot-%d.png -vcodec libx264 -crf 25 -pix_fmt yuv420p {videoName}";
            //strCmdText = "mkdir prueba";
            cmd.StandardInput.WriteLine(strCmdText);
            cmd.StandardInput.Flush();
            cmd.StandardInput.Close();
            cmd.WaitForExit();




        }


       

        public void Stop()
        {
            //Stop watch:
            watch.Stop();

         
            SaveVideo();

            DeleteFilesExcept(tempPath, tempPath + "\\" + videoName);
        }
    }
}